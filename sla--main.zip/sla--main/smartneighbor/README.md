# 🌎 SmartNeighbor — React

Versão React do projeto `agoravai.html`, reorganizada em **arquitetura por camadas** para ficar fácil de manter e evoluir.

## ▶️ Como rodar

```bash
npm install
npm run dev      # ambiente de desenvolvimento
npm run build    # build de produção
npm run preview  # serve o build local
```

Acesse `http://localhost:5173`.

## 🏗️ Arquitetura por camadas

```
src/
├── pages/          → Páginas (composição de seções)
│   └── HomePage.jsx
│
├── components/     → UI dividida em camadas
│   ├── layout/         (Navbar, BottomNav)
│   ├── sections/       (Hero, LoginCard, DoarCard, RankingCard, ...)
│   ├── effects/        (SnowCanvas, UrsoMascote)
│   └── ui/             (Card, Button, Input, Toast)
│
├── context/        → Estado global via React Context
│   ├── AuthContext.jsx
│   ├── DadosContext.jsx
│   └── ToastContext.jsx
│
├── hooks/          → Lógica reutilizável (custom hooks)
│   ├── useScrollReveal.js
│   ├── useSnow.js
│   └── useCountUp.js
│
├── services/       → Regras de negócio + persistência
│   ├── storage.js
│   └── doacaoService.js
│
├── utils/          → Helpers puros (formatação, etc.)
│   └── format.js
│
└── styles/
    └── global.css
```

### Por que separar assim?

| Camada      | Responsabilidade                                          |
| ----------- | --------------------------------------------------------- |
| `pages`     | Quais seções aparecem na tela, ordem e estrutura geral.   |
| `components`| Pedaços visuais reutilizáveis — não conhecem o "negócio". |
| `context`   | Estado global (usuário logado, doações, notificações).    |
| `hooks`     | Encapsulam efeitos colaterais e lógica de UI.             |
| `services`  | Regras de domínio + acesso ao `localStorage` (futuramente: API). |
| `utils`     | Funções puras (formatação `Intl`, helpers genéricos).     |

## ✨ Destaques

- Componentização completa.
- Estado global com **Context API**.
- **Custom hooks** para neve, scroll-reveal e contador animado.
- **Toasts** em vez de `alert`.
- **Validação** de login e doação.
- **Sugestões rápidas** de valor (chips R$ 25, 50, 100, 250).
- **Gráfico** com `react-chartjs-2`.
- **Formatação BRL** com `Intl.NumberFormat`.
- **Persistência** isolada em `services/storage.js` (fácil trocar por Firebase / API).
- **Responsivo** (navbar vira menu hambúrguer no mobile).
- **Acessibilidade** básica (`aria-label`, `<main>`, `<section>`, `<nav>`).
- Animações fluidas: Ken Burns no hero, shine no título, gradient shimmer no botão,
  glow seguindo o mouse nos cards, stagger no ranking, `prefers-reduced-motion` respeitado.
