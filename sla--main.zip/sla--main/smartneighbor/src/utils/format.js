export const formatBRL = (valor) =>
  new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    maximumFractionDigits: 0,
  }).format(Number(valor) || 0);

export const formatNumero = (valor) =>
  new Intl.NumberFormat('pt-BR').format(Number(valor) || 0);
