export default function Button({
  children,
  variant = 'primary',
  type = 'button',
  className = '',
  ...rest
}) {
  return (
    <button type={type} className={`btn btn--${variant} ${className}`} {...rest}>
      {children}
    </button>
  );
}
