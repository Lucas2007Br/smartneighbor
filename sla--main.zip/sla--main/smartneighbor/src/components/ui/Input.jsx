export default function Input({ label, id, className = '', ...rest }) {
  return (
    <label className={`input-field ${className}`} htmlFor={id}>
      {label && <span className="input-field__label">{label}</span>}
      <input id={id} className="input-field__control" {...rest} />
    </label>
  );
}
