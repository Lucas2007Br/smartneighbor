export default function Toast({ mensagem, tipo = 'info', onClose }) {
  return (
    <div className={`toast toast--${tipo}`} role="status">
      <span>{mensagem}</span>
      <button
        type="button"
        className="toast__close"
        onClick={onClose}
        aria-label="Fechar"
      >
        ×
      </button>
    </div>
  );
}
