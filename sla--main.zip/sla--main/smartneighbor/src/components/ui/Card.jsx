import { useScrollReveal } from '../../hooks/useScrollReveal';

export default function Card({ children, className = '', reveal = true, as: Tag = 'div' }) {
  const [ref, visivel] = useScrollReveal();
  const classes = ['card', reveal && 'reveal', reveal && visivel && 'visible', className]
    .filter(Boolean)
    .join(' ');

  const moverGlow = (e) => {
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', `${((e.clientX - r.left) / r.width) * 100}%`);
    el.style.setProperty('--my', `${((e.clientY - r.top) / r.height) * 100}%`);
  };

  return (
    <Tag
      ref={reveal ? ref : undefined}
      className={classes}
      onMouseMove={moverGlow}
    >
      {children}
    </Tag>
  );
}
