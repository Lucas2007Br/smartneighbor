import { useDados } from '../../context/DadosContext';
import { useCountUp } from '../../hooks/useCountUp';
import { formatBRL, formatNumero } from '../../utils/format';

export default function Hero() {
  const { dados } = useDados();
  const total = useCountUp(dados.total);
  const familias = useCountUp(dados.familias);

  return (
    <section className="hero" id="home">
      <div className="hero__bg" aria-hidden="true" />
      <div className="hero__overlay">
        <p className="hero__tagline anim-fade-down" style={{ animationDelay: '0.05s' }}>
          ONG · Vizinhança solidária
        </p>
        <h1 className="hero__title anim-fade-down" style={{ animationDelay: '0.15s' }}>
          SmartNeighbor
        </h1>
        <p className="hero__subtitle anim-fade-down" style={{ animationDelay: '0.3s' }}>
          Conectando vizinhos para transformar comunidades desde 2018.
        </p>
        <div className="hero__stats anim-fade-up" style={{ animationDelay: '0.45s' }}>
          <div>
            <strong>{formatBRL(total)}</strong>
            <span>arrecadados</span>
          </div>
          <div>
            <strong>{formatNumero(familias)}</strong>
            <span>famílias</span>
          </div>
        </div>
      </div>
    </section>
  );
}
