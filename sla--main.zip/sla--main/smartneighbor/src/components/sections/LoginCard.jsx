import { useState } from 'react';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function LoginCard() {
  const { user, login, logout, autenticado } = useAuth();
  const { mostrar } = useToast();
  const [email, setEmail] = useState('');

  const enviar = (e) => {
    e.preventDefault();
    try {
      login(email);
      mostrar('Bem-vindo(a)! 💙', 'sucesso');
      setEmail('');
    } catch (err) {
      mostrar(err.message, 'erro');
    }
  };

  return (
    <Card>
      <h3>👤 Sua conta</h3>
      {autenticado ? (
        <>
          <p>
            Logado como <strong>{user}</strong>
          </p>
          <Button variant="ghost" onClick={logout}>
            Sair
          </Button>
        </>
      ) : (
        <form onSubmit={enviar} className="form-stack">
          <Input
            id="email"
            type="email"
            label="E-mail"
            placeholder="voce@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit">Entrar</Button>
        </form>
      )}
    </Card>
  );
}
