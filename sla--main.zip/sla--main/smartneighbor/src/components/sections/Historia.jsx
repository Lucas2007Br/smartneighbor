import Card from '../ui/Card';

export default function Historia() {
  return (
    <Card>
      <h2>🌙 Onde tudo começou</h2>
      <p>
        Era uma noite fria de junho. Poucas pessoas decidiram agir,
        levando cobertores e sopa a famílias em situação de rua.
      </p>
      <p>
        Hoje, milhares de vidas foram impactadas e a corrente do bem
        só cresce. Cada doação representa uma noite mais quente
        para alguém que precisa.
      </p>
    </Card>
  );
}
