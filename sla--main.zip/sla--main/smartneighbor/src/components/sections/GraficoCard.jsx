import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import Card from '../ui/Card';
import { useDados } from '../../context/DadosContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

export default function GraficoCard() {
  const { dados } = useDados();

  const chartData = {
    labels: dados.historico.map((h) => h.mes),
    datasets: [
      {
        label: 'Doações (R$)',
        data: dados.historico.map((h) => h.valor),
        borderColor: '#00e5ff',
        backgroundColor: 'rgba(0, 229, 255, 0.18)',
        fill: true,
        tension: 0.35,
        pointBackgroundColor: '#00e5ff',
        pointRadius: 5,
      },
    ],
  };

  const opts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: '#cdeef3' } },
      tooltip: { intersect: false, mode: 'index' },
    },
    scales: {
      x: { ticks: { color: '#9fc6cf' }, grid: { color: 'rgba(255,255,255,0.05)' } },
      y: { ticks: { color: '#9fc6cf' }, grid: { color: 'rgba(255,255,255,0.05)' } },
    },
  };

  return (
    <Card className="card--grafico">
      <h3>📈 Evolução das doações</h3>
      <div className="grafico-box">
        <Line data={chartData} options={opts} />
      </div>
    </Card>
  );
}
