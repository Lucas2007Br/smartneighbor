import Card from '../ui/Card';
import { useDados } from '../../context/DadosContext';
import { useCountUp } from '../../hooks/useCountUp';
import { formatNumero } from '../../utils/format';

export default function FamiliasCard() {
  const { dados } = useDados();
  const familias = useCountUp(dados.familias);
  return (
    <Card>
      <h3>🏘️ Famílias impactadas</h3>
      <h1 className="big-number">{formatNumero(familias)}</h1>
      <p className="card__meta">
        Cada R$ 10 doados aquecem uma família por uma noite.
      </p>
    </Card>
  );
}
