import Card from '../ui/Card';
import { useDados } from '../../context/DadosContext';
import { formatBRL } from '../../utils/format';

const MEDALHAS = ['🥇', '🥈', '🥉'];

export default function RankingCard() {
  const { dados } = useDados();
  const top = dados.ranking.slice(0, 5);

  return (
    <Card>
      <h3>🏆 Ranking de doadores</h3>
      {top.length === 0 ? (
        <p className="card__meta">Seja o primeiro a doar e apareça aqui!</p>
      ) : (
        <ol className="ranking">
          {top.map((r, i) => (
            <li
              key={`${r.nome}-${r.data || i}`}
              className="ranking__item anim-fade-up"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <span className="ranking__pos">{MEDALHAS[i] || `${i + 1}º`}</span>
              <span className="ranking__nome">{r.nome}</span>
              <span className="ranking__valor">{formatBRL(r.valor)}</span>
            </li>
          ))}
        </ol>
      )}
    </Card>
  );
}
