import { useState } from 'react';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { useDados } from '../../context/DadosContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useCountUp } from '../../hooks/useCountUp';
import { formatBRL } from '../../utils/format';

const SUGESTOES = [25, 50, 100, 250];

export default function DoarCard() {
  const { dados, doar } = useDados();
  const { user, autenticado } = useAuth();
  const { mostrar } = useToast();
  const [valor, setValor] = useState('');
  const totalAnim = useCountUp(dados.total);

  const enviar = (e) => {
    e.preventDefault();
    try {
      doar({ nome: user, valor: parseInt(valor, 10) });
      mostrar(`Obrigado! ${formatBRL(valor)} doados 💙`, 'sucesso');
      setValor('');
    } catch (err) {
      mostrar(err.message, 'erro');
    }
  };

  return (
    <Card>
      <h3>💝 Faça uma doação</h3>

      <form onSubmit={enviar} className="form-stack">
        <Input
          id="valor"
          type="number"
          inputMode="numeric"
          min="1"
          label="Valor (R$)"
          placeholder="0,00"
          value={valor}
          onChange={(e) => setValor(e.target.value)}
          required
        />

        <div className="chips">
          {SUGESTOES.map((v) => (
            <button
              key={v}
              type="button"
              className={`chip ${Number(valor) === v ? 'is-active' : ''}`}
              onClick={() => setValor(String(v))}
            >
              {formatBRL(v)}
            </button>
          ))}
        </div>

        <Button type="submit" disabled={!autenticado}>
          {autenticado ? 'Doar agora' : 'Faça login para doar'}
        </Button>
      </form>

      <p className="card__meta">
        Total já arrecadado: <strong>{formatBRL(totalAnim)}</strong>
      </p>
    </Card>
  );
}
