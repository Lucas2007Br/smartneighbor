import { useState } from 'react';

const itens = [
  { id: 'home', label: 'Home', icone: '🏠' },
  { id: 'impacto', label: 'Impacto', icone: '🌱' },
  { id: 'doar', label: 'Doar', icone: '💝' },
  { id: 'ranking', label: 'Ranking', icone: '🏆' },
];

export default function Navbar({ secaoAtiva, onSelecionar }) {
  const [aberto, setAberto] = useState(false);

  const clicar = (id) => {
    setAberto(false);
    onSelecionar?.(id);
  };

  return (
    <header className="navbar">
      <div className="navbar__inner">
        <a
          href="#home"
          className="navbar__brand"
          onClick={() => clicar('home')}
        >
          <span className="navbar__brand-icon">🌎</span>
          <span>SmartNeighbor</span>
        </a>

        <button
          type="button"
          className="navbar__toggle"
          aria-label="Abrir menu"
          aria-expanded={aberto}
          onClick={() => setAberto((v) => !v)}
        >
          {aberto ? '✕' : '☰'}
        </button>

        <nav className={`navbar__nav ${aberto ? 'is-open' : ''}`}>
          {itens.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className={`navbar__link ${
                secaoAtiva === item.id ? 'is-active' : ''
              }`}
              onClick={() => clicar(item.id)}
            >
              <span className="navbar__icone">{item.icone}</span>
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
