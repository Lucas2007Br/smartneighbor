const itens = [
  { id: 'home', icone: '🏠' },
  { id: 'doar', icone: '💳' },
  { id: 'impacto', icone: '📊' },
  { id: 'ranking', icone: '🏆' },
];

export default function BottomNav({ secaoAtiva, onSelecionar }) {
  return (
    <nav className="bottom-nav">
      {itens.map((item) => (
        <button
          key={item.id}
          type="button"
          className={`bottom-nav__btn ${secaoAtiva === item.id ? 'is-active' : ''}`}
          onClick={() => onSelecionar?.(item.id)}
          aria-label={item.id}
        >
          {item.icone}
        </button>
      ))}
    </nav>
  );
}
