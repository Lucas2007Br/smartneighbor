import { useState } from 'react';

const FRASES = [
  '💙 Vamos ajudar alguém hoje?',
  '🔥 Você faz a diferença!',
  '🌍 Juntos mudamos o mundo!',
  '🐻 Um abraço quentinho pra você!',
  '✨ Pequenos gestos, grandes histórias.',
];

export default function UrsoMascote() {
  const [fala, setFala] = useState('');

  const falar = () => {
    const frase = FRASES[Math.floor(Math.random() * FRASES.length)];
    setFala(frase);
    setTimeout(() => setFala(''), 3000);
  };

  return (
    <div className="urso-wrap">
      {fala && <div className="urso-fala">{fala}</div>}
      <button
        type="button"
        className="urso"
        onClick={falar}
        aria-label="Falar com o mascote"
      >
        <img
          src="https://cdn-icons-png.flaticon.com/512/616/616408.png"
          alt="Urso mascote"
        />
      </button>
    </div>
  );
}
