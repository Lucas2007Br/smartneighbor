import { useSnow } from '../../hooks/useSnow';

export default function SnowCanvas() {
  const ref = useSnow(90);
  return <canvas ref={ref} className="snow-canvas" aria-hidden="true" />;
}
