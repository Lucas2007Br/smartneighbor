import { AuthProvider } from './context/AuthContext';
import { DadosProvider } from './context/DadosContext';
import { ToastProvider } from './context/ToastContext';
import HomePage from './pages/HomePage';

export default function App() {
  return (
    <AuthProvider>
      <DadosProvider>
        <ToastProvider>
          <HomePage />
        </ToastProvider>
      </DadosProvider>
    </AuthProvider>
  );
}
