const STORAGE_KEY = 'smartneighbor:dados';

export const dadosIniciais = {
  total: 10000,
  familias: 18000,
  ranking: [],
  historico: [
    { mes: 'Jan', valor: 2000 },
    { mes: 'Fev', valor: 4000 },
    { mes: 'Mar', valor: 6000 },
    { mes: 'Abr', valor: 7000 },
    { mes: 'Mai', valor: 9000 },
    { mes: 'Jun', valor: 10000 },
  ],
};

export const storageService = {
  carregar() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return dadosIniciais;
      const parsed = JSON.parse(raw);
      return { ...dadosIniciais, ...parsed };
    } catch {
      return dadosIniciais;
    }
  },

  salvar(dados) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dados));
    } catch {
      void 0;
    }
  },

  limpar() {
    localStorage.removeItem(STORAGE_KEY);
  },
};
