const FAMILIAS_POR_REAL = 1 / 10;

export const doacaoService = {
  registrarDoacao(dadosAtuais, { nome, valor }) {
    if (!valor || valor <= 0) {
      throw new Error('Informe um valor de doação maior que zero.');
    }
    if (!nome) {
      throw new Error('Faça login antes de doar.');
    }

    const novoTotal = dadosAtuais.total + valor;
    const novasFamilias =
      dadosAtuais.familias + Math.floor(valor * FAMILIAS_POR_REAL);

    const novoRanking = [...dadosAtuais.ranking, { nome, valor, data: Date.now() }]
      .sort((a, b) => b.valor - a.valor)
      .slice(0, 50);

    const ultimoMes = dadosAtuais.historico[dadosAtuais.historico.length - 1];
    const novoHistorico = [
      ...dadosAtuais.historico.slice(0, -1),
      { ...ultimoMes, valor: novoTotal },
    ];

    return {
      ...dadosAtuais,
      total: novoTotal,
      familias: novasFamilias,
      ranking: novoRanking,
      historico: novoHistorico,
    };
  },
};
