import { useState } from 'react';
import Navbar from '../components/layout/Navbar';
import BottomNav from '../components/layout/BottomNav';
import Hero from '../components/sections/Hero';
import Historia from '../components/sections/Historia';
import LoginCard from '../components/sections/LoginCard';
import DoarCard from '../components/sections/DoarCard';
import FamiliasCard from '../components/sections/FamiliasCard';
import RankingCard from '../components/sections/RankingCard';
import GraficoCard from '../components/sections/GraficoCard';
import SnowCanvas from '../components/effects/SnowCanvas';
import UrsoMascote from '../components/effects/UrsoMascote';

export default function HomePage() {
  const [secao, setSecao] = useState('home');

  const irPara = (id) => {
    setSecao(id);
    const alvo = document.getElementById(id);
    if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="app-shell">
      <SnowCanvas />
      <Navbar secaoAtiva={secao} onSelecionar={irPara} />

      <main className="main">
        <Hero />

        <section className="stack">
          <Historia />
        </section>

        <section id="doar" className="grid">
          <LoginCard />
          <DoarCard />
        </section>

        <section id="impacto" className="grid">
          <FamiliasCard />
          <RankingCard />
        </section>

        <section id="ranking" className="stack">
          <GraficoCard />
        </section>
      </main>

      <UrsoMascote />
      <BottomNav secaoAtiva={secao} onSelecionar={irPara} />
    </div>
  );
}
