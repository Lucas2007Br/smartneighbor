import { createContext, useContext, useState, useCallback } from 'react';
import Toast from '../components/ui/Toast';

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const remover = useCallback((id) => {
    setToasts((atual) => atual.filter((t) => t.id !== id));
  }, []);

  const mostrar = useCallback(
    (mensagem, tipo = 'info') => {
      const id = crypto.randomUUID();
      setToasts((atual) => [...atual, { id, mensagem, tipo }]);
      setTimeout(() => remover(id), 3500);
    },
    [remover]
  );

  return (
    <ToastContext.Provider value={{ mostrar }}>
      {children}
      <div className="toast-stack">
        {toasts.map((t) => (
          <Toast key={t.id} {...t} onClose={() => remover(t.id)} />
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast precisa estar dentro de <ToastProvider>');
  return ctx;
}
