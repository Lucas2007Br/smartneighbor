import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { storageService } from '../services/storage';
import { doacaoService } from '../services/doacaoService';

const DadosContext = createContext(null);

export function DadosProvider({ children }) {
  const [dados, setDados] = useState(() => storageService.carregar());

  useEffect(() => {
    storageService.salvar(dados);
  }, [dados]);

  const doar = useCallback((info) => {
    setDados((atual) => doacaoService.registrarDoacao(atual, info));
  }, []);

  const resetar = useCallback(() => {
    storageService.limpar();
    setDados(storageService.carregar());
  }, []);

  return (
    <DadosContext.Provider value={{ dados, doar, resetar }}>
      {children}
    </DadosContext.Provider>
  );
}

export function useDados() {
  const ctx = useContext(DadosContext);
  if (!ctx) throw new Error('useDados precisa estar dentro de <DadosProvider>');
  return ctx;
}
