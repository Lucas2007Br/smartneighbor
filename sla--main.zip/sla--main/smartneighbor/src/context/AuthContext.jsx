import { createContext, useContext, useState, useCallback } from 'react';

const AuthContext = createContext(null);

const USER_KEY = 'smartneighbor:user';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => localStorage.getItem(USER_KEY) || '');

  const login = useCallback((email) => {
    const limpo = (email || '').trim();
    if (!limpo) throw new Error('Informe um e-mail válido.');
    if (!limpo.includes('@')) throw new Error('E-mail em formato inválido.');
    localStorage.setItem(USER_KEY, limpo);
    setUser(limpo);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(USER_KEY);
    setUser('');
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, logout, autenticado: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth precisa estar dentro de <AuthProvider>');
  return ctx;
}
