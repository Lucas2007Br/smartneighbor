import { useEffect, useRef } from 'react';

export function useSnow(quantidade = 80) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let raf;
    let flocos = [];

    const init = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      flocos = Array.from({ length: quantidade }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 2 + 1,
        v: Math.random() * 1 + 0.5,
      }));
    };

    const desenhar = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      flocos.forEach((n) => {
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();
        n.y += n.v;
        if (n.y > canvas.height) {
          n.y = 0;
          n.x = Math.random() * canvas.width;
        }
      });
      raf = requestAnimationFrame(desenhar);
    };

    init();
    desenhar();
    window.addEventListener('resize', init);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', init);
    };
  }, [quantidade]);

  return canvasRef;
}
