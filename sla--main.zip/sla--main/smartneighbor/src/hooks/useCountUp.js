import { useEffect, useRef, useState } from 'react';

export function useCountUp(valor, duracao = 900) {
  const [atual, setAtual] = useState(valor);
  const anteriorRef = useRef(valor);

  useEffect(() => {
    const inicio = anteriorRef.current;
    const fim = valor;
    if (inicio === fim) return;

    const t0 = performance.now();
    let raf;

    const passo = (now) => {
      const p = Math.min((now - t0) / duracao, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setAtual(Math.round(inicio + (fim - inicio) * eased));
      if (p < 1) raf = requestAnimationFrame(passo);
      else anteriorRef.current = fim;
    };

    raf = requestAnimationFrame(passo);
    return () => cancelAnimationFrame(raf);
  }, [valor, duracao]);

  return atual;
}
